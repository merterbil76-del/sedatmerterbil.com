const STORAGE_KEY = "klinik-defter-data-v1";

const today = new Date();
const isoToday = formatDateInput(today);

const seedData = createSampleData();

function createSampleData() {
  const clientsWithContext = [
    {
      id: "c01",
      name: "Deniz Kaya",
      nationalId: "90000000001",
      phone: "+90 432 001 55 66",
      email: "deniz.kaya@example.com",
      contact: "Kadıköy / Tercih edilen iletişim: WhatsApp",
      focus: "kaygı yönetimi ve iş yaşamı dengesi",
      path: "individual",
      notes: "Kaygı yönetimi ve iş yaşamı dengesi üzerine çalışılıyor. Seanslarda somatik farkındalık egzersizlerine olumlu yanıt veriyor."
    },
    {
      id: "c02",
      name: "Ece Arslan",
      nationalId: "90000000002",
      phone: "+90 432 002 44 44",
      email: "ece.arslan@example.com",
      contact: "Online görüşme tercih ediyor.",
      focus: "uyku rutini ve otomatik düşünceler",
      path: "individual",
      notes: "Uyku rutini, ilişki sınırları ve otomatik düşünceler takip ediliyor. Ev ödevlerini düzenli getiriyor."
    },
    {
      id: "c03",
      name: "Mert Demir",
      nationalId: "90000000003",
      phone: "+90 432 003 18 40",
      email: "mert.demir@example.com",
      contact: "Acil durumda e-posta ile ulaşılmasını istiyor.",
      focus: "erteleme davranışı ve performans kaygısı",
      path: "individual",
      notes: "Performans kaygısı ve erteleme döngüsü üzerinde çalışılıyor. Haftalık davranış aktivasyonu planı izleniyor."
    },
    {
      id: "c04",
      name: "Selin Özkan",
      nationalId: "90000000004",
      phone: "+90 432 004 19 22",
      email: "selin.ozkan@example.com",
      contact: "Beşiktaş / Akşam saatleri uygun.",
      focus: "sınır koyma ve öz şefkat",
      path: "individual",
      notes: "Sınır koyma, öz şefkat ve aile ilişkileri üzerine çalışılıyor. Duygu günlüğü faydalı oluyor."
    },
    {
      id: "c05",
      name: "Burak Yılmaz",
      nationalId: "90000000005",
      phone: "+90 432 005 72 84",
      email: "burak.yilmaz@example.com",
      contact: "Online / Kredi kartı ile ödeme tercih ediyor.",
      focus: "panik belirtiler ve bedensel duyumlar",
      path: "individual",
      notes: "Panik belirtiler ve bedensel duyumlara yönelik psiko-eğitim verildi. Maruz bırakma planı kademeli ilerliyor."
    },
    {
      id: "c06",
      name: "Aylin Şahin",
      nationalId: "90000000006",
      phone: "+90 432 006 05 90",
      email: "aylin.sahin@example.com",
      contact: "Ataşehir / Seans hatırlatması SMS ile yapılacak.",
      focus: "yas süreci ve duygu regülasyonu",
      path: "individual",
      notes: "Yas süreci ve duygu regülasyonu üzerine çalışılıyor. Destek kaynakları ve ritüeller değerlendiriliyor."
    },
    {
      id: "c07",
      name: "Caner ve Duru Aksoy",
      nationalId: "90000000007",
      phone: "+90 432 007 66 31",
      email: "aksoy.cift@example.com",
      contact: "Çift terapisi / Ortak e-posta kullanılıyor.",
      focus: "iletişim döngüleri ve çatışma çözümü",
      path: "couple",
      notes: "Çift terapisi süreci devam ediyor. İletişim döngüleri, çatışma anında mola ve aktif dinleme çalışılıyor."
    },
    {
      id: "c08",
      name: "Yasemin Koç",
      nationalId: "90000000008",
      phone: "+90 432 008 28 14",
      email: "yasemin.koc@example.com",
      contact: "Nişantaşı / Öğle saatlerini tercih ediyor.",
      focus: "mükemmeliyetçilik ve iş stresi",
      path: "individual",
      notes: "Mükemmeliyetçilik, iş stresi ve öz değer temaları takip ediliyor. Düşünce kayıtları düzenli inceleniyor."
    },
    {
      id: "c09",
      name: "Emre Aydın",
      nationalId: "90000000009",
      phone: "+90 432 009 90 75",
      email: "emre.aydin@example.com",
      contact: "Üsküdar / Nakit ödeme tercih ediyor.",
      focus: "sosyal kaygı ve kaçınma davranışları",
      path: "individual",
      notes: "Sosyal kaygı ve kaçınma davranışları üzerine çalışılıyor. Küçük sosyal deneyler planlanıyor."
    },
    {
      id: "c10",
      name: "Zeynep Güneş",
      nationalId: "90000000010",
      phone: "+90 432 000 10 10",
      email: "zeynep.gunes@example.com",
      contact: "Online / Fatura bilgileri her ay sonunda isteniyor.",
      focus: "tükenmişlik ve yaşam düzeni",
      path: "individual",
      notes: "Tükenmişlik, çalışma düzeni ve dinlenme sınırları üzerine çalışılıyor. Haftalık enerji takibi yapılıyor."
    },
    {
      id: "c11",
      name: "İrem ve Kerem Polat",
      nationalId: "90000000011",
      phone: "+90 432 000 11 11",
      email: "polat.cift@example.com",
      contact: "Çift terapisi / Hafta sonu seansı tercih ediyorlar.",
      focus: "güven onarımı ve ilişki sözleşmeleri",
      path: "couple",
      notes: "Güven onarımı, ilişki sözleşmeleri ve sorumluluk paylaşımı ele alınıyor. Ortak ev ödevleri takip ediliyor."
    },
    {
      id: "c12",
      name: "Onur Çelik",
      nationalId: "90000000012",
      phone: "+90 432 000 12 12",
      email: "onur.celik@example.com",
      contact: "Bakırköy / Sabah saatleri uygun.",
      focus: "öfke farkındalığı ve dürtü kontrolü",
      path: "individual",
      notes: "Öfke farkındalığı, dürtü kontrolü ve beden sinyallerini erken fark etme becerileri çalışılıyor."
    }
  ];

  const unpaidIndexes = new Set([4, 9, 14, 19, 24, 29, 34, 39, 44, 49, 54, 59, 64, 69]);
  const havaleIndexes = new Set([11, 29, 47, 65]);
  const sessionHours = ["09:30", "11:00", "13:30", "15:00", "16:30", "18:00"];
  const noteStages = [
    "İlk değerlendirme yapıldı; başvuru nedeni, beklentiler ve hedefler netleştirildi.",
    "Haftalık duygu takibi incelendi; tetikleyici durumlar ve otomatik düşünceler ayrıştırıldı.",
    "Seans içinde başa çıkma becerileri denendi; ev ödevi olarak kısa günlük kayıt önerildi.",
    "Önceki haftanın zorlayıcı anları değerlendirildi; alternatif tepki seçenekleri çalışıldı.",
    "İlerleme, direnç noktaları ve günlük yaşam uygulamaları birlikte gözden geçirildi.",
    "Süreç değerlendirmesi yapıldı; bir sonraki dönem için takip hedefleri belirlendi."
  ];

  const sessions = [];

  clientsWithContext.forEach((client, clientIndex) => {
    for (let sessionIndex = 0; sessionIndex < 6; sessionIndex += 1) {
      const globalIndex = clientIndex * 6 + sessionIndex;
      const isCouple = client.path === "couple";
      const sessionType = isCouple ? "Çift terapisi" : (sessionIndex === 0 ? "Ön görüşme" : "Seans");
      const fee = isCouple ? 3300 : (sessionIndex === 0 ? 1700 + (clientIndex % 3) * 100 : 2100 + (clientIndex % 4) * 150);
      const invoiceIssued = globalIndex % 4 !== 3;
      const paymentMethod = havaleIndexes.has(globalIndex)
        ? "Havale"
        : (globalIndex % 2 === 0 ? "Nakit" : "Kredi kartı");

      sessions.push({
        id: `s${String(globalIndex + 1).padStart(3, "0")}`,
        clientId: client.id,
        date: shiftDate(-82 + clientIndex * 2 + sessionIndex * 14),
        time: sessionHours[(clientIndex + sessionIndex) % sessionHours.length],
        type: sessionType,
        fee,
        paid: !unpaidIndexes.has(globalIndex),
        paymentMethod,
        invoiceNumber: invoiceIssued ? `KD-2026-${String(globalIndex + 101).padStart(3, "0")}` : "",
        invoiceTotal: invoiceIssued ? fee : 0,
        notes: `${noteStages[sessionIndex]} Odak alanı: ${client.focus}.`
      });
    }
  });

  const clients = clientsWithContext.map(({ focus, path, ...client }) => client);

  return {
    selectedClientId: clients[0].id,
    clients,
    sessions
  };
}

let state = loadState();

const els = {
  navItems: document.querySelectorAll(".nav-item"),
  views: document.querySelectorAll(".view"),
  reportForm: document.getElementById("reportForm"),
  reportStart: document.getElementById("reportStart"),
  reportEnd: document.getElementById("reportEnd"),
  metricGrid: document.getElementById("metricGrid"),
  upcomingSessions: document.getElementById("upcomingSessions"),
  paymentDonut: document.getElementById("paymentDonut"),
  paymentLegend: document.getElementById("paymentLegend"),
  clientSearch: document.getElementById("clientSearch"),
  clientList: document.getElementById("clientList"),
  clientDetail: document.getElementById("clientDetail"),
  sessionsTable: document.getElementById("sessionsTable"),
  clientModal: document.getElementById("clientModal"),
  clientForm: document.getElementById("clientForm"),
  clientModalTitle: document.getElementById("clientModalTitle"),
  clientId: document.getElementById("clientId"),
  clientName: document.getElementById("clientName"),
  clientNationalId: document.getElementById("clientNationalId"),
  clientPhone: document.getElementById("clientPhone"),
  clientEmail: document.getElementById("clientEmail"),
  clientContact: document.getElementById("clientContact"),
  clientNotes: document.getElementById("clientNotes"),
  deleteClientBtn: document.getElementById("deleteClientBtn"),
  sessionModal: document.getElementById("sessionModal"),
  sessionForm: document.getElementById("sessionForm"),
  sessionModalTitle: document.getElementById("sessionModalTitle"),
  sessionId: document.getElementById("sessionId"),
  sessionClient: document.getElementById("sessionClient"),
  sessionDate: document.getElementById("sessionDate"),
  sessionTime: document.getElementById("sessionTime"),
  sessionType: document.getElementById("sessionType"),
  sessionFee: document.getElementById("sessionFee"),
  paymentMethod: document.getElementById("paymentMethod"),
  paymentPaid: document.getElementById("paymentPaid"),
  invoiceNumber: document.getElementById("invoiceNumber"),
  invoiceTotal: document.getElementById("invoiceTotal"),
  sessionNotes: document.getElementById("sessionNotes"),
  deleteSessionBtn: document.getElementById("deleteSessionBtn"),
  newClientBtn: document.getElementById("newClientBtn"),
  newSessionBtn: document.getElementById("newSessionBtn"),
  quickSessionBtn: document.getElementById("quickSessionBtn"),
  importDataBtn: document.getElementById("importDataBtn"),
  importFileInput: document.getElementById("importFileInput"),
  exportDataBtn: document.getElementById("exportDataBtn"),
  toast: document.getElementById("toast")
};

init();
registerServiceWorker();

function init() {
  setDefaultReportRange();
  bindEvents();
  render();
}

function bindEvents() {
  els.navItems.forEach((item) => {
    item.addEventListener("click", (event) => {
      event.preventDefault();
      setView(item.dataset.view);
    });
  });

  els.reportForm.addEventListener("submit", (event) => {
    event.preventDefault();
    renderDashboard();
  });

  els.clientSearch.addEventListener("input", renderClients);
  els.newClientBtn.addEventListener("click", () => openClientModal());
  els.newSessionBtn.addEventListener("click", () => openSessionModal());
  els.quickSessionBtn.addEventListener("click", () => openSessionModal(null, state.selectedClientId));
  els.importDataBtn.addEventListener("click", requestImportFile);
  els.importFileInput.addEventListener("change", importDataFromFile);
  els.exportDataBtn.addEventListener("click", exportData);

  document.querySelectorAll("[data-close-modal]").forEach((button) => {
    button.addEventListener("click", () => closeModal(button.dataset.closeModal));
  });

  [els.clientModal, els.sessionModal].forEach((modal) => {
    modal.addEventListener("close", updateModalLock);
  });

  els.clientForm.addEventListener("submit", saveClientFromForm);
  els.sessionForm.addEventListener("submit", saveSessionFromForm);
  els.deleteClientBtn.addEventListener("click", deleteCurrentClient);
  els.deleteSessionBtn.addEventListener("click", deleteCurrentSession);

  els.clientDetail.addEventListener("click", (event) => {
    const action = event.target.closest("[data-action]");
    if (!action) return;

    const { action: actionName, clientId, sessionId } = action.dataset;
    if (actionName === "edit-client") openClientModal(clientId);
    if (actionName === "add-session") openSessionModal(null, clientId);
    if (actionName === "edit-session") openSessionModal(sessionId);
  });

  els.sessionsTable.addEventListener("click", (event) => {
    const button = event.target.closest("[data-session-id]");
    if (button) openSessionModal(button.dataset.sessionId);
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      closeModal("clientModal");
      closeModal("sessionModal");
    }
  });
}

function render() {
  normalizeSelection();
  populateClientSelect();
  renderDashboard();
  renderClients();
  renderSessionsTable();
  saveState();
}

function setView(viewName) {
  els.navItems.forEach((item) => item.classList.toggle("active", item.dataset.view === viewName));
  els.views.forEach((view) => view.classList.toggle("active", view.id === `${viewName}View`));
}

function renderDashboard() {
  const range = getReportRange();
  const rangeSessions = state.sessions.filter((session) => isInRange(session.date, range.start, range.end));
  const totalSessions = rangeSessions.length;
  const totalPaid = sum(rangeSessions.filter((session) => session.paid), "fee");
  const totalReceivable = sum(rangeSessions.filter((session) => !session.paid), "fee");
  const totalRevenue = totalPaid + totalReceivable;
  const invoiceTotal = sum(rangeSessions, "invoiceTotal");

  const metrics = [
    { label: "Toplam seans", value: totalSessions.toLocaleString("tr-TR"), icon: "#" },
    { label: "Toplam tahsilat", value: money(totalPaid), icon: "TL" },
    { label: "Toplam alacak", value: money(totalReceivable), icon: "!" },
    { label: "Toplam ciro", value: money(totalRevenue), icon: "C" },
    { label: "Kesilen fatura", value: money(invoiceTotal), icon: "F" }
  ];

  els.metricGrid.innerHTML = metrics.map((metric) => `
    <article class="metric-card">
      <span>${escapeHtml(metric.icon)}</span>
      <p>${escapeHtml(metric.label)}</p>
      <strong>${escapeHtml(metric.value)}</strong>
    </article>
  `).join("");

  renderUpcomingSessions();
  renderPaymentVisual(rangeSessions);
}

function renderUpcomingSessions() {
  const rows = state.sessions
    .filter((session) => session.date >= isoToday)
    .sort(sortSessionsAsc)
    .slice(0, 6)
    .map((session) => {
      const client = getClient(session.clientId);
      return `
        <tr>
          <td><strong>${escapeHtml(client?.name ?? "Silinmiş danışan")}</strong></td>
          <td>${escapeHtml(formatDate(session.date))} · ${escapeHtml(session.time)}</td>
          <td><span class="pill">${escapeHtml(session.type)}</span></td>
          <td><span class="pill ${session.paid ? "paid" : "unpaid"}">${session.paid ? "Ödendi" : "Alacak"}</span></td>
        </tr>
      `;
    })
    .join("");

  els.upcomingSessions.innerHTML = rows || `<tr><td class="empty-row" colspan="4">Yaklaşan seans bulunmuyor.</td></tr>`;
}

function renderPaymentVisual(sessions) {
  const paid = sum(sessions.filter((session) => session.paid), "fee");
  const unpaid = sum(sessions.filter((session) => !session.paid), "fee");
  const total = paid + unpaid;
  const paidDegree = total > 0 ? Math.round((paid / total) * 360) : 0;

  els.paymentDonut.style.background = total > 0
    ? `conic-gradient(var(--success) 0deg ${paidDegree}deg, var(--warning) ${paidDegree}deg 360deg)`
    : "conic-gradient(var(--surface-muted) 0deg 360deg)";

  els.paymentLegend.innerHTML = `
    <div class="legend-row">
      <span class="legend-dot paid" aria-hidden="true"></span>
      <span>Tahsil edildi</span>
      <strong>${escapeHtml(money(paid))}</strong>
    </div>
    <div class="legend-row">
      <span class="legend-dot unpaid" aria-hidden="true"></span>
      <span>Alacak</span>
      <strong>${escapeHtml(money(unpaid))}</strong>
    </div>
    <div class="legend-row">
      <span class="legend-dot" style="background: var(--surface-muted)" aria-hidden="true"></span>
      <span>Toplam işlem</span>
      <strong>${escapeHtml(String(sessions.length))}</strong>
    </div>
  `;
}

function renderClients() {
  const query = els.clientSearch.value.trim().toLocaleLowerCase("tr-TR");
  const clients = state.clients
    .filter((client) => !query || [client.name, client.phone, client.email, client.nationalId].join(" ").toLocaleLowerCase("tr-TR").includes(query))
    .sort((a, b) => a.name.localeCompare(b.name, "tr"));

  els.clientList.innerHTML = clients.map((client) => {
    const sessionCount = getClientSessions(client.id).length;
    return `
      <button class="client-card-button ${client.id === state.selectedClientId ? "active" : ""}" type="button" data-client-id="${escapeHtml(client.id)}">
        <span class="avatar" aria-hidden="true">${escapeHtml(initials(client.name))}</span>
        <span>
          <strong>${escapeHtml(client.name)}</strong>
          <span>${escapeHtml(client.phone || client.email || "İletişim bilgisi yok")}</span>
        </span>
        <span class="client-count">${sessionCount}</span>
      </button>
    `;
  }).join("") || `<div class="empty-state"><strong>Kayıt bulunamadı</strong><p>Arama kriterine uyan danışan yok.</p></div>`;

  els.clientList.querySelectorAll("[data-client-id]").forEach((button) => {
    button.addEventListener("click", () => {
      state.selectedClientId = button.dataset.clientId;
      render();
    });
  });

  renderClientDetail();
}

function renderClientDetail() {
  const client = getClient(state.selectedClientId);
  if (!client) {
    els.clientDetail.innerHTML = `
      <div class="empty-state">
        <strong>Danışan seçin</strong>
        <p>Sol listeden bir danışan seçerek kartını, notlarını ve seans takvimini görüntüleyin.</p>
      </div>
    `;
    return;
  }

  const sessions = getClientSessions(client.id).sort(sortSessionsDesc);
  const lastSession = sessions[0];

  els.clientDetail.innerHTML = `
    <div class="detail-hero">
      <div class="detail-title">
        <span class="avatar" aria-hidden="true">${escapeHtml(initials(client.name))}</span>
        <div>
          <h2>${escapeHtml(client.name)}</h2>
          <p>${escapeHtml(lastSession ? `Son seans: ${formatDate(lastSession.date)} · ${lastSession.time}` : "Henüz seans kaydı yok")}</p>
        </div>
      </div>
      <div class="detail-actions">
        <button class="ghost-button" type="button" data-action="edit-client" data-client-id="${escapeHtml(client.id)}">Kartı düzenle</button>
        <button class="primary-button" type="button" data-action="add-session" data-client-id="${escapeHtml(client.id)}">Seans ekle</button>
      </div>
    </div>

    <div class="info-grid">
      ${infoItem("T.C. kimlik no", client.nationalId || "Belirtilmedi")}
      ${infoItem("Telefon", client.phone || "Belirtilmedi")}
      ${infoItem("E-posta", client.email || "Belirtilmedi")}
      ${infoItem("İletişim", client.contact || "Belirtilmedi")}
    </div>

    <section class="detail-section">
      <div class="detail-section-header">
        <div>
          <h3>Genel notlar</h3>
          <p>Danışana ait seans dışı klinik ve süreç notları.</p>
        </div>
      </div>
      <div class="notes-box">${escapeHtml(client.notes || "Henüz genel not girilmedi.")}</div>
    </section>

    <section class="detail-section">
      <div class="detail-section-header">
        <div>
          <h3>Son 3 aylık seans takvimi</h3>
          <p>Renkli günlerin üzerine gelerek ilgili seans özetini görün.</p>
        </div>
      </div>
      <div class="calendar-grid">${renderCalendar(client.id)}</div>
    </section>

    <section class="detail-section">
      <div class="detail-section-header">
        <div>
          <h3>Geçmiş seans bilgileri</h3>
          <p>Tarih, ödeme, fatura ve seans notlarının kısa görünümü.</p>
        </div>
      </div>
      <div class="session-list">
        ${sessions.map(renderSessionItem).join("") || `<div class="empty-state"><strong>Seans yok</strong><p>Bu danışana ait seans kaydı eklenmedi.</p></div>`}
      </div>
    </section>
  `;
}

function renderSessionsTable() {
  const rows = state.sessions
    .slice()
    .sort(sortSessionsDesc)
    .map((session) => {
      const client = getClient(session.clientId);
      return `
        <tr>
          <td><strong>${escapeHtml(client?.name ?? "Silinmiş danışan")}</strong></td>
          <td>${escapeHtml(formatDate(session.date))}</td>
          <td>${escapeHtml(session.time)}</td>
          <td><span class="pill">${escapeHtml(session.type)}</span></td>
          <td>${escapeHtml(money(session.fee))}</td>
          <td><span class="pill ${session.paid ? "paid" : "unpaid"}">${session.paid ? "Ödendi" : "Ödenmedi"}</span></td>
          <td>${session.invoiceNumber ? `<span class="pill invoice">${escapeHtml(session.invoiceNumber)}</span>` : `<span class="muted">Yok</span>`}</td>
          <td><button class="mini-button" type="button" data-session-id="${escapeHtml(session.id)}">Düzenle</button></td>
        </tr>
      `;
    })
    .join("");

  els.sessionsTable.innerHTML = rows || `<tr><td class="empty-row" colspan="8">Henüz seans kaydı yok.</td></tr>`;
}

function renderCalendar(clientId) {
  const months = [2, 1, 0].map((offset) => {
    const date = new Date(today.getFullYear(), today.getMonth() - offset, 1);
    return renderMonth(date, clientId);
  });
  return months.join("");
}

function renderMonth(date, clientId) {
  const year = date.getFullYear();
  const month = date.getMonth();
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const startOffset = (firstDay.getDay() + 6) % 7;
  const totalSlots = Math.ceil((startOffset + lastDay.getDate()) / 7) * 7;
  const clientSessions = getClientSessions(clientId);
  const weekdayNames = ["Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz"];

  let days = "";
  for (let slot = 0; slot < totalSlots; slot += 1) {
    const dayNumber = slot - startOffset + 1;
    if (dayNumber < 1 || dayNumber > lastDay.getDate()) {
      days += `<span class="day" aria-hidden="true"></span>`;
      continue;
    }

    const dayIso = formatDateInput(new Date(year, month, dayNumber));
    const sessions = clientSessions.filter((session) => session.date === dayIso);
    const tooltip = sessions.length ? renderTooltip(sessions) : "";
    days += `
      <span class="day ${sessions.length ? "session-day" : ""}">
        ${dayNumber}
        ${tooltip}
      </span>
    `;
  }

  return `
    <article class="month">
      <h4>${escapeHtml(monthName(date))}</h4>
      <div class="weekdays">${weekdayNames.map((day) => `<span>${day}</span>`).join("")}</div>
      <div class="days">${days}</div>
    </article>
  `;
}

function renderTooltip(sessions) {
  const content = sessions.map((session) => `
    <strong>${escapeHtml(session.time)} · ${escapeHtml(session.type)}</strong>
    <span>${escapeHtml(money(session.fee))} · ${session.paid ? "Ödendi" : "Ödenmedi"} · ${escapeHtml(session.paymentMethod)}</span>
    ${session.notes ? `<span>${escapeHtml(truncate(session.notes, 82))}</span>` : ""}
  `).join("");

  return `<span class="session-tooltip">${content}</span>`;
}

function renderSessionItem(session) {
  return `
    <article class="session-item">
      <div class="session-date">
        <strong>${escapeHtml(formatDate(session.date))}</strong>
        <span>${escapeHtml(session.time)} · ${escapeHtml(session.type)}</span>
      </div>
      <div class="session-main">
        <strong>${escapeHtml(money(session.fee))} · ${session.paid ? "Ödendi" : "Ödenmedi"}</strong>
        <span>${escapeHtml(session.paymentMethod)}${session.invoiceNumber ? ` · Fatura ${escapeHtml(session.invoiceNumber)}` : ""}</span>
        <span>${escapeHtml(truncate(session.notes || "Seans notu girilmedi.", 140))}</span>
      </div>
      <button class="mini-button" type="button" data-action="edit-session" data-session-id="${escapeHtml(session.id)}">Düzenle</button>
    </article>
  `;
}

function openClientModal(clientId = null) {
  const client = clientId ? getClient(clientId) : null;
  els.clientModalTitle.textContent = client ? "Danışan kartını düzenle" : "Yeni danışan";
  els.clientId.value = client?.id ?? "";
  els.clientName.value = client?.name ?? "";
  els.clientNationalId.value = client?.nationalId ?? "";
  els.clientPhone.value = client?.phone ?? "";
  els.clientEmail.value = client?.email ?? "";
  els.clientContact.value = client?.contact ?? "";
  els.clientNotes.value = client?.notes ?? "";
  els.deleteClientBtn.style.visibility = client ? "visible" : "hidden";
  openModal(els.clientModal);
  els.clientName.focus();
}

function openSessionModal(sessionId = null, preferredClientId = null) {
  if (!state.clients.length) {
    showToast("Önce bir danışan kartı oluşturun.");
    openClientModal();
    return;
  }

  populateClientSelect();
  const session = sessionId ? getSession(sessionId) : null;
  els.sessionModalTitle.textContent = session ? "Seans kaydını düzenle" : "Yeni seans";
  els.sessionId.value = session?.id ?? "";
  els.sessionClient.value = session?.clientId ?? preferredClientId ?? state.selectedClientId ?? state.clients[0].id;
  els.sessionDate.value = session?.date ?? isoToday;
  els.sessionTime.value = session?.time ?? "10:00";
  els.sessionType.value = session?.type ?? "Seans";
  els.sessionFee.value = session?.fee ?? "";
  els.paymentMethod.value = session?.paymentMethod ?? "Nakit";
  els.paymentPaid.checked = Boolean(session?.paid);
  els.invoiceNumber.value = session?.invoiceNumber ?? "";
  els.invoiceTotal.value = session?.invoiceTotal || "";
  els.sessionNotes.value = session?.notes ?? "";
  els.deleteSessionBtn.style.visibility = session ? "visible" : "hidden";
  openModal(els.sessionModal);
  els.sessionClient.focus();
}

function saveClientFromForm(event) {
  event.preventDefault();
  const id = els.clientId.value || makeId("c");
  const client = {
    id,
    name: clean(els.clientName.value),
    nationalId: clean(els.clientNationalId.value),
    phone: clean(els.clientPhone.value),
    email: clean(els.clientEmail.value),
    contact: clean(els.clientContact.value),
    notes: clean(els.clientNotes.value)
  };

  if (!client.name) {
    showToast("Danışan adı zorunlu.");
    return;
  }

  const index = state.clients.findIndex((item) => item.id === id);
  if (index >= 0) state.clients[index] = client;
  else state.clients.push(client);

  state.selectedClientId = id;
  closeModal("clientModal");
  showToast("Danışan kartı kaydedildi.");
  render();
}

function saveSessionFromForm(event) {
  event.preventDefault();
  const id = els.sessionId.value || makeId("s");
  const session = {
    id,
    clientId: els.sessionClient.value,
    date: els.sessionDate.value,
    time: els.sessionTime.value,
    type: els.sessionType.value || "Seans",
    fee: numberValue(els.sessionFee.value),
    paid: els.paymentPaid.checked,
    paymentMethod: els.paymentMethod.value,
    invoiceNumber: clean(els.invoiceNumber.value),
    invoiceTotal: numberValue(els.invoiceTotal.value),
    notes: clean(els.sessionNotes.value)
  };

  if (!session.clientId || !session.date || !session.time) {
    showToast("Danışan, tarih ve saat alanları zorunlu.");
    return;
  }

  const index = state.sessions.findIndex((item) => item.id === id);
  if (index >= 0) state.sessions[index] = session;
  else state.sessions.push(session);

  state.selectedClientId = session.clientId;
  closeModal("sessionModal");
  showToast("Seans kaydı kaydedildi.");
  render();
}

function deleteCurrentClient() {
  const id = els.clientId.value;
  if (!id) return;
  const client = getClient(id);
  const confirmed = window.confirm(`${client?.name ?? "Bu danışan"} ve ilişkili tüm seanslar silinsin mi?`);
  if (!confirmed) return;

  state.clients = state.clients.filter((item) => item.id !== id);
  state.sessions = state.sessions.filter((item) => item.clientId !== id);
  state.selectedClientId = state.clients[0]?.id ?? null;
  closeModal("clientModal");
  showToast("Danışan kartı silindi.");
  render();
}

function deleteCurrentSession() {
  const id = els.sessionId.value;
  if (!id) return;
  const confirmed = window.confirm("Bu seans kaydı silinsin mi?");
  if (!confirmed) return;

  state.sessions = state.sessions.filter((item) => item.id !== id);
  closeModal("sessionModal");
  showToast("Seans kaydı silindi.");
  render();
}

function exportData() {
  const payload = JSON.stringify({ exportedAt: new Date().toISOString(), ...state }, null, 2);
  const blob = new Blob([payload], { type: "application/json;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `klinik-defter-yedek-${isoToday}.json`;
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
  showToast("Veriler JSON olarak dışa aktarıldı.");
}

function requestImportFile() {
  els.importFileInput.value = "";
  els.importFileInput.click();
}

async function importDataFromFile(event) {
  const file = event.target.files?.[0];
  if (!file) return;

  try {
    const imported = normalizeImportedData(JSON.parse(await file.text()));
    const confirmed = window.confirm(
      `${file.name} dosyasındaki ${imported.clients.length} danışan ve ${imported.sessions.length} seans mevcut verilerin yerine yüklensin mi?`
    );

    if (!confirmed) {
      showToast("İçe aktarma iptal edildi.");
      return;
    }

    state = imported;
    normalizeSelection();
    saveState();
    render();
    showToast("Yedek başarıyla içe aktarıldı.");
  } catch (error) {
    showToast(error.message || "Yedek dosyası okunamadı.");
  } finally {
    els.importFileInput.value = "";
  }
}

function normalizeImportedData(data) {
  if (!data || !Array.isArray(data.clients) || !Array.isArray(data.sessions)) {
    throw new Error("Seçilen dosya geçerli bir Klinik Defter yedeği değil.");
  }

  const clients = data.clients
    .filter((client) => client && client.id && client.name)
    .map((client) => ({
      id: clean(client.id),
      name: clean(client.name),
      nationalId: clean(client.nationalId),
      phone: clean(client.phone),
      email: clean(client.email),
      contact: clean(client.contact),
      notes: clean(client.notes)
    }));

  const clientIds = new Set(clients.map((client) => client.id));
  const sessions = data.sessions
    .filter((session) => session && session.id && clientIds.has(session.clientId) && session.date && session.time)
    .map((session) => ({
      id: clean(session.id),
      clientId: clean(session.clientId),
      date: clean(session.date),
      time: clean(session.time),
      type: clean(session.type) || "Seans",
      fee: numberValue(session.fee),
      paid: Boolean(session.paid),
      paymentMethod: clean(session.paymentMethod) || "Nakit",
      invoiceNumber: clean(session.invoiceNumber),
      invoiceTotal: numberValue(session.invoiceTotal),
      notes: clean(session.notes)
    }));

  if (!clients.length) {
    throw new Error("Yedekte içe aktarılabilecek danışan kaydı bulunamadı.");
  }

  return {
    selectedClientId: clientIds.has(data.selectedClientId) ? data.selectedClientId : clients[0].id,
    clients,
    sessions
  };
}

function populateClientSelect() {
  els.sessionClient.innerHTML = state.clients
    .slice()
    .sort((a, b) => a.name.localeCompare(b.name, "tr"))
    .map((client) => `<option value="${escapeHtml(client.id)}">${escapeHtml(client.name)}</option>`)
    .join("");
}

function setDefaultReportRange() {
  const start = new Date(today.getFullYear(), today.getMonth(), 1);
  const end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
  els.reportStart.value = formatDateInput(start);
  els.reportEnd.value = formatDateInput(end);
}

function getReportRange() {
  const start = els.reportStart.value || "1900-01-01";
  const end = els.reportEnd.value || "2999-12-31";
  return start <= end ? { start, end } : { start: end, end: start };
}

function normalizeSelection() {
  if (!state.clients.some((client) => client.id === state.selectedClientId)) {
    state.selectedClientId = state.clients[0]?.id ?? null;
  }
}

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return structuredClone(seedData);
    const parsed = JSON.parse(raw);
    if (isLegacyDemoData(parsed) || isOutdatedSamplePhoneData(parsed)) return structuredClone(seedData);
    return {
      selectedClientId: parsed.selectedClientId ?? parsed.clients?.[0]?.id ?? null,
      clients: Array.isArray(parsed.clients) ? parsed.clients : [],
      sessions: Array.isArray(parsed.sessions) ? parsed.sessions : []
    };
  } catch {
    return structuredClone(seedData);
  }
}

function isLegacyDemoData(data) {
  if (!data || !Array.isArray(data.clients) || !Array.isArray(data.sessions)) return false;
  const names = data.clients.map((client) => client?.name).sort().join("|");
  return data.clients.length === 3
    && data.sessions.length === 7
    && names === "Deniz Kaya|Ece Arslan|Mert Demir";
}

function isOutdatedSamplePhoneData(data) {
  if (!data || !Array.isArray(data.clients) || !Array.isArray(data.sessions)) return false;
  const expectedIds = new Set(Array.from({ length: 12 }, (_, index) => `c${String(index + 1).padStart(2, "0")}`));
  const hasSampleShape = data.clients.length === 12
    && data.sessions.length === 72
    && data.clients.every((client) => expectedIds.has(client?.id));

  return hasSampleShape && data.clients.some((client) => /^\+90 5/.test(client.phone || ""));
}

function saveState() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // Some locked-down file previews can block browser storage.
  }
}

function getClient(id) {
  return state.clients.find((client) => client.id === id);
}

function getSession(id) {
  return state.sessions.find((session) => session.id === id);
}

function getClientSessions(clientId) {
  return state.sessions.filter((session) => session.clientId === clientId);
}

function isInRange(date, start, end) {
  return date >= start && date <= end;
}

function sum(items, key) {
  return items.reduce((total, item) => total + numberValue(item[key]), 0);
}

function numberValue(value) {
  const number = Number(value);
  return Number.isFinite(number) ? number : 0;
}

function sortSessionsAsc(a, b) {
  return `${a.date}T${a.time}`.localeCompare(`${b.date}T${b.time}`);
}

function sortSessionsDesc(a, b) {
  return sortSessionsAsc(b, a);
}

function money(value) {
  return new Intl.NumberFormat("tr-TR", {
    style: "currency",
    currency: "TRY",
    maximumFractionDigits: 0
  }).format(numberValue(value));
}

function formatDate(value) {
  return new Intl.DateTimeFormat("tr-TR", {
    day: "2-digit",
    month: "short",
    year: "numeric"
  }).format(new Date(`${value}T12:00:00`));
}

function formatDateInput(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function shiftDate(dayOffset) {
  const date = new Date(today);
  date.setDate(today.getDate() + dayOffset);
  return formatDateInput(date);
}

function monthName(date) {
  return new Intl.DateTimeFormat("tr-TR", {
    month: "long",
    year: "numeric"
  }).format(date);
}

function initials(name) {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0])
    .join("")
    .toLocaleUpperCase("tr-TR");
}

function truncate(value, limit) {
  return value.length > limit ? `${value.slice(0, limit - 1)}...` : value;
}

function clean(value) {
  return String(value ?? "").trim();
}

function makeId(prefix) {
  return `${prefix}${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
}

function infoItem(label, value) {
  return `
    <div class="info-item">
      <span>${escapeHtml(label)}</span>
      <strong>${escapeHtml(value)}</strong>
    </div>
  `;
}

function closeModal(id) {
  const modal = document.getElementById(id);
  if (modal?.open) modal.close();
}

function openModal(modal) {
  modal.showModal();
  updateModalLock();
}

function updateModalLock() {
  document.body.classList.toggle("modal-open", Boolean(document.querySelector("dialog[open]")));
}

function showToast(message) {
  els.toast.textContent = message;
  els.toast.classList.add("show");
  window.clearTimeout(showToast.timeout);
  showToast.timeout = window.setTimeout(() => {
    els.toast.classList.remove("show");
  }, 2600);
}

function registerServiceWorker() {
  if (!("serviceWorker" in navigator) || !window.location.protocol.startsWith("http")) return;

  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./sw.js").catch(() => {
      // Local file previews and locked-down browsers can block service workers.
    });
  });
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
