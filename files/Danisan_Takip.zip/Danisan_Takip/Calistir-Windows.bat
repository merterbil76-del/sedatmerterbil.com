@echo off
setlocal

cd /d "%~dp0"
set "PORT=4174"
set "URL=http://localhost:%PORT%/"
set "APP_FILE=%~dp0index.html"
set "LOG_FILE=%TEMP%\klinik-defter-server-%PORT%.log"

echo Klinik Defter baslatiliyor...
echo.

where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  set "PY_EXE=py"
  set "PY_ARGS=-3"
) else (
  where python >nul 2>nul
  if %ERRORLEVEL% EQU 0 (
    set "PY_EXE=python"
    set "PY_ARGS="
  ) else (
    echo Python bulunamadi. Uygulama dogrudan tarayicida aciliyor.
    start "" "%APP_FILE%"
    exit /b 0
  )
)

netstat -ano | findstr /R /C:":%PORT% .*LISTENING" >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  echo Uygulama zaten calisiyor.
  start "" "%URL%"
  exit /b 0
)

echo Yerel sunucu aciliyor: %URL%
echo Sunucu arka planda calisacak; bu pencere kapanacak.
echo.

start "Klinik Defter Sunucu" /min "%COMSPEC%" /c "%PY_EXE% %PY_ARGS% -m http.server %PORT% --bind 127.0.0.1 > "%LOG_FILE%" 2>&1"
timeout /t 1 /nobreak >nul
start "" "%URL%"
exit /b 0
