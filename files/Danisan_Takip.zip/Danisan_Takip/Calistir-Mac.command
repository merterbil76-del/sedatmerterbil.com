#!/bin/zsh

cd "$(dirname "$0")" || exit 1

PORT=4174
URL="http://localhost:${PORT}/"
APP_FILE="$(pwd)/index.html"
LOG_FILE="${TMPDIR:-/tmp}/klinik-defter-server-${PORT}.log"
TERMINAL_WINDOW_ID="$(osascript -e 'tell application "Terminal" to id of front window' 2>/dev/null)"

close_terminal_window() {
  if [[ -n "${TERMINAL_WINDOW_ID}" ]]; then
    (sleep 0.5; osascript -e "tell application \"Terminal\" to close (first window whose id is ${TERMINAL_WINDOW_ID})") >/dev/null 2>&1 &
    disown $! 2>/dev/null
  fi
}

clear
echo "Klinik Defter baslatiliyor..."
echo ""

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 bulunamadi. Uygulama dogrudan tarayicida aciliyor."
  open "${APP_FILE}"
  close_terminal_window
  exit 0
fi

if lsof -nP -iTCP:${PORT} -sTCP:LISTEN >/dev/null 2>&1; then
  echo "Uygulama zaten calisiyor."
  echo "Tarayici aciliyor: ${URL}"
  open "${URL}"
  close_terminal_window
  exit 0
fi

echo "Yerel sunucu aciliyor: ${URL}"
echo "Sunucu arka planda calisacak; Terminal penceresi otomatik kapanacak."
echo ""

nohup python3 -m http.server "${PORT}" --bind 127.0.0.1 > "${LOG_FILE}" 2>&1 &
SERVER_PID=$!
disown "${SERVER_PID}" 2>/dev/null
sleep 1

if lsof -nP -iTCP:${PORT} -sTCP:LISTEN >/dev/null 2>&1; then
  open "${URL}"
  close_terminal_window
  exit 0
fi

osascript -e 'display dialog "Klinik Defter baslatilamadi. Lutfen Python 3 kurulumunu ve klasor izinlerini kontrol edin." buttons {"Tamam"} default button "Tamam"' >/dev/null 2>&1
open "${APP_FILE}"
close_terminal_window
exit 0
